'use strict';
const AWS = require('aws-sdk');
const DDB = new AWS.DynamoDB.DocumentClient();

AWS.config.update({region: 'us-east-2'});

module.exports.slackReadBudget = async event => {
  try{
    if(!event.month) return {statusCode: 400, body: "Missing Input Param: month"};
    const monthlyBudget = await DDB.get({
      Key: { 
        "pk": { S: "may" }
      }, 
      TableName: "SlackBudgets"
     });
     console.log(monthlyBudget);
     return {
       statusCode: 200,
       body: JSON.stringify(monthlyBudget)
     };
  }
  catch(error){
    console.log(error);
    return {
      statusCode: 500,
      body: error.toString()
    };
  };
};
